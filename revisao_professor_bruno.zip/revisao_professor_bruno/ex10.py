vlrA = int(input('Digite um valor: '))

a = str(vlrA)

print(a[::-1])