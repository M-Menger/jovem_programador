Api Multas

1.Ler arquivo DbMultas Ok
    -Função SearchAIT()
    usando biblioteca openpyxl
2.Buscar conteudos a partir do Auto da Multas
    -Função SearchAIT()
    Faz um laço for para buscar a AIT inserida no inicio do programa
3.Montar texto pré definido com informações encontradas
    -Função SearchAIT()
    Busca os dados selecionados e inseri a partir da F.String no texto pré Definido
4.Enviar email, com titulo, corpo destinatario e destinatarios em cópia
    -Função sendMail()
    Envia os dados obtidos através da função SearchAIT()
5.Inserir data e horário do envio do email em campo especifico
    -Função endProccess()
    usando biblioteca openpyxl
    Salva a data de envio na coluna H da respectiva AIT

RV001061
X002885598
