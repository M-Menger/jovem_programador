import openpyxl
from datetime import datetime
import win32com.client as win32

#------------------Variaveis

auto = str(input('Cole o auto aqui:  '))

#Function's

def sendMail():

    outlook = win32.Dispatch('outlook.application')

    email = outlook.CreateItem(0)

    email.To = 'matheus-menger@hotmail.com'
    email.Subject = resSearch[0]
    email.Body = resSearch[1]
    email.Send()

    timeSend = datetime.now()

    return timeSend


def searchAIT():

    dataBase = openpyxl.load_workbook('DBMultas.xlsx')

    mySheetdb = dataBase['DBMultas']

    for row in range (1,200):
        for column in 'P':
            search = f'{column}{row}'
            if mySheetdb[search].value == auto:
                idCar = mySheetdb[f'K{row}'].value
                data = mySheetdb[f'O{row}'].value
                vlr = mySheetdb[f'AA{row}'].value
                cep = mySheetdb[f'W{row}'].value
                city = mySheetdb[f'X{row}'].value
                infr = mySheetdb[f'Z{row}'].value
                mail = mySheetdb[f'D{row}'].value
                resp = mySheetdb[f'C{row}'].value
                thisCell = (f'H{row}')
                status = True
                title = f'\nALERTA: Indicação de Condutor, placa {idCar} auto de infração {auto}\n'
                body = f'Venho através deste notificar o Auto de infração n° {auto} Cometido com o veículo placa {idCar},\nno dia {data} no valor de {vlr*0.8:.2f}R$, Por {infr}. \nInfração cometida em {cep} na cidade de {city}. \n\nFAVOR ENVIAR PRIMEIRAMENTE A CNH DO INFRATOR (PREFERENCIALMENTE O ARQUIVO DIGITAL) PARA QUE EU POSSO GERAR O TERMO EM SEU NOME E ENVIAR PARA ASSINATURA.'
            elif row == 200:
                status = False
                title = ''
                body = ''
                thisCell = ''
                
    return title, body, thisCell, mail, resp, status

def endProccess():
    dataBase = openpyxl.load_workbook('DBMultas.xlsx')
    mySheetdb = dataBase['DBMultas']

    thisCell = resSearch[2]
    dateNow = datetime.now()
    mySheetdb[thisCell] = dateNow

    dataBase.save('DBMultas.xlsx')

    return mySheetdb[thisCell].value


#Main

resSearch = searchAIT()

if resSearch[5] == True:
    timeSend = sendMail()
    result = endProccess()
else:
    print('AIT invalida, favor veirifique o auto.')

print(result)

