import openpyxl
from datetime import datetime
import win32com.client as win32

#------------------Variaveis

#auto = str(input('Cole o auto aqui:  '))
auto = 'X002885598'

#Function's

def searchAIT():

    dataBase = openpyxl.load_workbook('DBMultas.xlsx')

    mySheetdb = dataBase['DBMultas']

    for row in range (1,200):
        for column in 'P':
            search = f'{column}{row}'
            if mySheetdb[search].value == auto:
                thisCell = row
    return thisCell


def pegaDados(numCell):

    dataBase = openpyxl.load_workbook('DBMultas.xlsx', data_only= True)
    mySheetdb = dataBase['DBMultas']

    idCar = mySheetdb[f'K{numCell}'].value
    data = mySheetdb[f'O{numCell}'].value
    vlr = mySheetdb[f'AA{numCell}'].value
    cep = mySheetdb[f'W{numCell}'].value
    city = mySheetdb[f'X{numCell}'].value
    infr = mySheetdb[f'Z{numCell}'].value

    return idCar, data, vlr, infr, cep, city


def sendMail(a,b):

    outlook = win32.Dispatch('outlook.application')

    email = outlook.CreateItem(0)

    email.To = 'matheus-menger@hotmail.com'
    email.Subject = title
    email.Body = body
    email.Send()

    timeSend = datetime.now()

    return timeSend


resSearch = searchAIT()
resDados = pegaDados(resSearch)

title = f'ALERTA: Indicação de Condutor, placa {resDados[0]} auto de infração {auto}'

body = f'''Venho através deste notificar o Auto de infração n° {auto} Cometido com o veículo placa {resDados[0]}, 
no dia {resDados[1]} no valor de {resDados[2]*0.8:.2f}R$, Por {resDados[3]}. 
Infração cometida em {resDados[4]} na cidade de {resDados[5]}. 

FAVOR ENVIAR PRIMEIRAMENTE A CNH DO INFRATOR (PREFERENCIALMENTE O ARQUIVO DIGITAL) PARA QUE EU POSSA GERAR O TERMO EM SEU NOME E ENVIAR PARA ASSINATURA.'''


#searchAIT()

#pegaDados(resSearch)
print(title)
#print(resDados)


